function [R,T] = disambiguateRelativePose(Rots,u3,points0_h,points1_h,K1,K2)
% DISAMBIGUATERELATIVEPOSE- finds the correct relative camera pose (among
% four possible configurations) by returning the one that yields points
% lying in front of the image plane (with positive depth).
%
% Arguments:
%   Rots -  3x3x2: the two possible rotations returned by decomposeEssentialMatrix
%   u3   -  a 3x1 vector with the translation information returned by decomposeEssentialMatrix
%   p1   -  3xN homogeneous coordinates of point correspondences in image 1
%   p2   -  3xN homogeneous coordinates of point correspondences in image 2
%   K1   -  3x3 calibration matrix for camera 1
%   K2   -  3x3 calibration matrix for camera 2
%
% Returns:
%   R -  3x3 the correct rotation matrix
%   T -  3x1 the correct translation vector
%
%   where [R|t] = T_C2_C1 = T_C2_W is a transformation that maps points
%   from the world coordinate system (identical to the coordinate system of camera 1)
%   to camera 2.
%

%     M1=K1*[eye(3), zeros(3, 1)];
%     
%     M2_cand={};
%     
%     M2_cand{1}=K2*[Rots{1}, u3];
%     M2_cand{2}=K2*[Rots{2}, u3];
%     M2_cand{3}=K2*[Rots{1}, -u3];
%     M2_cand{4}=K2*[Rots{2}, -u3];
%     
%     b=0;
%     i=0;
%     
%     while b==false
%         i=i+1;
%         P=linearTriangulation(p1,p2,M1,M2_cand{i});
%         P2 = [K2\M2_cand{i}; 0 0 0 1]*P;
%         if all(P(3, :)>=0) && all(P2(3, :)>=0)
%             b=1;
%         end
%     end
%     
%     MAT=K2^(-1)*M2_cand{i};
%     
%     R=MAT(1:3, 1:3);
%     T=MAT(1:3, 4);

    [~,N] = size(points0_h);

    M1 = K1 * [eye(3), zeros(3,1)];
    M2_1 = K2 * [Rots{1}, u3];
    M2_2 = K2 * [Rots{2}, u3];
    M2_3 = K2 * [Rots{1}, -u3];
    M2_4 = K2 * [Rots{2}, -u3];
    num_z_neg = zeros(4,1);

    for i= 1:N
        P_1 = linearTriangulation(points0_h(:,i),points1_h(:,i),M1,M2_1);
        P_2 = linearTriangulation(points0_h(:,i),points1_h(:,i),M1,M2_2);
        P_3 = linearTriangulation(points0_h(:,i),points1_h(:,i),M1,M2_3);
        P_4 = linearTriangulation(points0_h(:,i),points1_h(:,i),M1,M2_4);
        if(P_1(3) < 0)
            num_z_neg(1,1) = num_z_neg(1,1) + 1;
        end
        if(P_2(3) < 0)
            num_z_neg(2,1) = num_z_neg(2,1) + 1;
        end
        if(P_3(3) < 0)
            num_z_neg(3,1) = num_z_neg(3,1) + 1;
        end
        if(P_4(3) < 0)
            num_z_neg(4,1) = num_z_neg(4,1) + 1;
        end
    end
    [~,index] = min(num_z_neg);
    index=3;
    if index == 1
        R = Rots{1};
        T = u3;
    elseif index == 2
        R = Rots{2}; 
        T = u3;
    elseif index == 3
        R = Rots{1};
        T = -u3;
    elseif index == 4
        R = Rots{2};
        T = -u3;

end
        
